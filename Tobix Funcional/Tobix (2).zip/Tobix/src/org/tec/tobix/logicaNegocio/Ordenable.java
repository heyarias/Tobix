package org.tec.tobix.logicaNegocio;

import java.util.ArrayList;

public interface Ordenable {
	public ArrayList<ArrayList> ordenamiento(ArrayList<Integer> sentimientos2, ArrayList<Integer> sentimientos1);

}

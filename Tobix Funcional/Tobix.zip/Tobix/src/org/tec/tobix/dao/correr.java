package org.tec.tobix.dao;

import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.util.Calendar;

import org.tec.tobix.logicaNegocio.Encargado;
import org.tec.tobix.logicaNegocio.Persona;

public class correr {

	public static void main(String[] args) throws SQLException, ParseException {
		ObtenerInformacion ob=new ObtenerInformacion();
		int hora, minutos, segundos;
		
		ob.selectHoraInicio(1);
		
		

		
		
	}

}
